<!DOCTYPE html>
<html>
<head>
    <title>Registration Form</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<body>
<h2>Registration Form</h2>
<h2>Output is on the same page</h2>

<form action="" method="POST">
    <label for="firstname">First name:</label><br>
    <input type="text" id="firstname" name="firstname"> <br><br>

    <label for="lastname">Last name:</label><br>
    <input type="text" id="lastname" name="lastname"> <br><br>

    <label for="password">Password:</label><br>
    <input type="password" id="password" name="password"> <br><br>

    <input type="submit" value="Submit">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    echo htmlspecialchars($_POST["firstname"]) . "<br>";
    echo htmlspecialchars($_POST["lastname"]) . "<br>";
}
?>
</body>
</html>


