 <section class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>Quality Online Education From Certified Tutors</h1>
                <p>Connect with expert tutors for personalized learning experiences tailored to your needs.</p>
                <div class="cta-buttons">
                    <a href="#" class="btn btn-primary btn-large">Find a Tutor</a>
                    <a href="#" class="btn btn-secondary btn-large">Become a Tutor</a>
                </div>
            </div>
            <div class="hero-image">
                <img src="images/online tuition.jpeg" alt="Online Learning">
            </div>
        </div>
    </section>
