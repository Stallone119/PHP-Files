<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>COGNITIO INSTITUTE</title>
    <link rel="stylesheet" href="style.css"> <!-- Optional CSS file -->
</head>
<body>
    <header>
        <h1>Welcome to COGNITIO INSTITUTE</h1>
        <nav>
            <ul>
                <li><a href="header.php">Home</a></li>
                <li><a href="home.php">About Us</a></li>
                <li><a href="section.php">Researchs</a></li>
                <li><a href="footer.php">Media</a></li>
                <!-- Add more links as needed -->
            </ul>
        </nav>
    </header>
    
