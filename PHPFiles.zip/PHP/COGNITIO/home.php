
<main>
    <section>
        <h2>Who We Are</h2>
        <p>COGNITIO INSTITUTE offers high-quality research support, data analysis, and academic consulting services tailored to clients' specific needs.</p>
    </section>

    <section>
        <h2>Our Services</h2>
        <ul>
            <li>Online Tuition</li>
            <li>Virtual Assignment Assistance</li>
            <li>Learning Materials</li>
            <li>Training for Teachers</li>
        </ul>
    </section>
</main>
