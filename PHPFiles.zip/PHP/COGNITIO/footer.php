    <footer>
        <p>&copy; <?php echo date("Y"); ?> COGNITIO INSTITUTE. All rights reserved.</p>
    </footer>
</body>
</html>
