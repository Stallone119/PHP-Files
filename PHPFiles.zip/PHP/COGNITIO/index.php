<?php
include("header.php");
include("home.php");
include("section.php");
include("footer.php");
?>
