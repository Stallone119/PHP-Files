
<?php
// Variables in PHP
$name = "Alice";
$age = 20;
echo "<h1>Name:</h1> <b> $name</b> <h1>Age:</h1> <b>$age</b>";
?>