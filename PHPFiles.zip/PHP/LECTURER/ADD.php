<?php
// PHP code goes here

echo "<h1> Hello, World! </h1>";
$num1 = 2;
$num2 = 3;

$sum = $num1 + $num2;

print $sum;

?>

