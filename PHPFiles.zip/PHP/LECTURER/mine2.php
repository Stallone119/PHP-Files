<?php
$score = 95;

if ($score >= 90) {
    echo "Grade: A";
} elseif ($score >= 75) {
    echo "Grade: B";
} else {
    echo "Grade: C";
}
?>