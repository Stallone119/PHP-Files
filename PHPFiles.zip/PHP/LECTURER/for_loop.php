
<h1>FOR LOOP</h1>

<?php
echo "For Loop <br>";
for ($i = 0; $i < 5; $i++) {
    echo "Number: $i <br>";
}

?>