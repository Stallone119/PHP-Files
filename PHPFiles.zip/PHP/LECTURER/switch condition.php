<?php

$day = "Monday";

switch ($day) {
    case "Monday":
        echo "<h1>Start of the week </h1>";
        break;
    case "Friday":
        echo "Weekend is near!";
        break;
    default:
        echo "Regular day";
}


?>