<?php
echo "<h1>WELCOME TO MY PROGRAM</h1>";
$name = "Jerome";
$age = 54;
echo "<h4>NAME:</h4><b>$name</b> <h4><b>AGE:</h4> <b>$age</b>"
?>