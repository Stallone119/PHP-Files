<?php
$colors = ["Red", "Green", "Blue"];
foreach ($colors as $color) {
    echo $color . "<br>";
}

?>
