<?php
$count = 1;

do {
    echo "Count is: $count<br>";
    $count++;
} while ($count <= 5);
?>