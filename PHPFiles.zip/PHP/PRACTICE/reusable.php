<?php
echo "Here is a very simple php statement. <br/>";
?>