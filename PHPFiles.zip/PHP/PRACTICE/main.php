<?php
echo "<h1>This is the main file.</h1> <br/>";
include("reusable.php");
echo "This script will end now.<br/>";
?>