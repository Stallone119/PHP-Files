document.addEventListener('DOMContentLoaded', function() {
    // Auth Modal Toggle
    const authModal = document.getElementById('auth-modal');
    const loginBtn = document.getElementById('login-btn');
    const signupBtn = document.getElementById('signup-btn');
    const closeModal = document.querySelector('.close-modal');
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    function toggleAuthModal() {
        authModal.classList.toggle('active');
        document.body.style.overflow = authModal.classList.contains('active') ? 'hidden' : '';
    }
    
    function switchTab(tabId) {
        tabBtns.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabId);
        });
        
        tabContents.forEach(content => {
            content.classList.toggle('active', content.id === tabId);
        });
    }
    
    loginBtn.addEventListener('click', function(e) {
        e.preventDefault();
        toggleAuthModal();
        switchTab('login');
    });
    
    signupBtn.addEventListener('click', function(e) {
        e.preventDefault();
        toggleAuthModal();
        switchTab('signup');
    });
    
    closeModal.addEventListener('click', toggleAuthModal);
    
    authModal.addEventListener('click', function(e) {
        if (e.target === authModal) {
            toggleAuthModal();
        }
    });
    
    tabBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            switchTab(this.dataset.tab);
        });
    });
    
    // Form Validation
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('login-email').value;
            const password = document.getElementById('login-password').value;
            
            // Simple validation
            if (!email || !password) {
                alert('Please fill in all fields');
                return;
            }
            
            // Here you would typically send the data to your backend
            console.log('Login attempt with:', { email, password });
            
            // For demo purposes, we'll simulate a successful login
            simulateLogin(email);
        });
    }
    
    if (signupForm) {
        signupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const userType = document.querySelector('input[name="user-type"]:checked').value;
            const name = document.getElementById('signup-name').value;
            const email = document.getElementById('signup-email').value;
            const password = document.getElementById('signup-password').value;
            const confirmPassword = document.getElementById('signup-confirm').value;
            
            // Validation
            if (!name || !email || !password || !confirmPassword) {
                alert('Please fill in all fields');
                return;
            }
            
            if (password !== confirmPassword) {
                alert('Passwords do not match');
                return;
            }
            
            if (password.length < 8) {
                alert('Password must be at least 8 characters long');
                return;
            }
            
            // Check for at least one number and one special character
            const hasNumber = /\d/.test(password);
            const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
            
            if (!hasNumber || !hasSpecialChar) {
                alert('Password must contain at least one number and one special character');
                return;
            }
            
            if (!document.getElementById('agree-terms').checked) {
                alert('You must agree to the terms and conditions');
                return;
            }
            
            // Here you would typically send the data to your backend
            console.log('Signup attempt with:', { userType, name, email, password });
            
            // For demo purposes, we'll simulate a successful signup
            simulateSignup(userType, name, email);
        });
    }
    
    // Simulate login/signup (for demo purposes)
    function simulateLogin(email) {
        // Show loading state
        const submitBtn = loginForm.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
        submitBtn.disabled = true;
        
        // Simulate API call
        setTimeout(() => {
            // Reset button
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
            
            // Close modal
            toggleAuthModal();
            
            // Show success message
            alert(`Welcome back! You've been logged in as ${email}`);
            
            // Redirect based on user type (in a real app, this would come from the backend)
            const userType = email.includes('tutor') ? 'tutor' : 
                            email.includes('parent') ? 'parent' : 
                            email.includes('admin') ? 'admin' : 'student';
            
            // For demo, we'll just show an alert
            alert(`Redirecting to ${userType} dashboard...`);
            // In a real app: window.location.href = `${userType}.html`;
        }, 1500);
    }
    
    function simulateSignup(userType, name, email) {
        // Show loading state
        const submitBtn = signupForm.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating account...';
        submitBtn.disabled = true;
        
        // Simulate API call
        setTimeout(() => {
            // Reset button
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
            
            // Close modal
            toggleAuthModal();
            
            // Show success message
            alert(`Welcome ${name}! Your ${userType} account has been created. Please check your email to verify your account.`);
            
            // For tutors, show additional message about approval process
            if (userType === 'tutor') {
                alert('As a tutor, your application will be reviewed by our admin team. You will receive an email once your account is approved.');
            }
        }, 2000);
    }
    
    // Password visibility toggle (for both forms)
    function setupPasswordToggle(formId, passwordFieldId) {
        const form = document.getElementById(formId);
        if (!form) return;
        
        const passwordField = document.getElementById(passwordFieldId);
        const toggleBtn = document.createElement('button');
        toggleBtn.type = 'button';
        toggleBtn.className = 'password-toggle';
        toggleBtn.innerHTML = '<i class="far fa-eye"></i>';
        
        // Insert after password field
        passwordField.parentNode.insertBefore(toggleBtn, passwordField.nextSibling);
        
        toggleBtn.addEventListener('click', function() {
            const isPassword = passwordField.type === 'password';
            passwordField.type = isPassword ? 'text' : 'password';
            toggleBtn.innerHTML = isPassword ? '<i class="far fa-eye-slash"></i>' : '<i class="far fa-eye"></i>';
        });
    }
    
    setupPasswordToggle('login-form', 'login-password');
    setupPasswordToggle('signup-form', 'signup-password');
    setupPasswordToggle('signup-form', 'signup-confirm');
});