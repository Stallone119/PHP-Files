document.addEventListener('DOMContentLoaded', function() {
    // Initialize Chart.js
    const progressChart = document.getElementById('progressChart');
    
    if (progressChart) {
        const ctx = progressChart.getContext('2d');
        const chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
                datasets: [
                    {
                        label: 'Mathematics',
                        data: [65, 70, 75, 80, 85, 82, 88],
                        borderColor: '#4a6bff',
                        backgroundColor: 'rgba(74, 107, 255, 0.1)',
                        tension: 0.3,
                        fill: true
                    },
                    {
                        label: 'Science',
                        data: [55, 60, 65, 70, 75, 78, 82],
                        borderColor: '#28a745',
                        backgroundColor: 'rgba(40, 167, 69, 0.1)',
                        tension: 0.3,
                        fill: true
                    },
                    {
                        label: 'English',
                        data: [70, 72, 75, 77, 80, 82, 85],
                        borderColor: '#ff6b6b',
                        backgroundColor: 'rgba(255, 107, 107, 0.1)',
                        tension: 0.3,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false,
                        min: 50,
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    }
                },
                interaction: {
                    mode: 'nearest',
                    axis: 'x',
                    intersect: false
                }
            }
        });
    }
    
    // Mobile menu toggle for dashboard
    const mobileMenuBtn = document.createElement('button');
    mobileMenuBtn.className = 'mobile-menu dashboard-menu';
    mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
    
    const dashboardHeader = document.querySelector('.dashboard-header');
    if (dashboardHeader) {
        dashboardHeader.insertBefore(mobileMenuBtn, dashboardHeader.firstChild);
        
        const dashboardNav = document.querySelector('.dashboard-nav');
        
        mobileMenuBtn.addEventListener('click', function() {
            dashboardNav.classList.toggle('active');
            mobileMenuBtn.innerHTML = dashboardNav.classList.contains('active') ? 
                '<i class="fas fa-times"></i>' : '<i class="fas fa-bars"></i>';
        });
    }
    
    // Notification dropdown
    const notificationBtn = document.querySelector('.notifications');
    if (notificationBtn) {
        const notificationDropdown = document.createElement('div');
        notificationDropdown.className = 'notification-dropdown';
        notificationDropdown.innerHTML = `
            <div class="notification-header">
                <h4>Notifications</h4>
                <button class="mark-all-read">Mark all as read</button>
            </div>
            <div class="notification-list">
                <div class="notification-item unread">
                    <div class="notification-icon">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <div class="notification-content">
                        <p>Your session with Dr. Johnson has been confirmed for tomorrow at 3:00 PM</p>
                        <span class="notification-time">2 hours ago</span>
                    </div>
                </div>
                <div class="notification-item unread">
                    <div class="notification-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="notification-content">
                        <p>New assignment posted in Advanced Calculus</p>
                        <span class="notification-time">1 day ago</span>
                    </div>
                </div>
                <div class="notification-item">
                    <div class="notification-icon">
                        <i class="fas fa-comment"></i>
                    </div>
                    <div class="notification-content">
                        <p>Prof. Kim sent you a message about your last session</p>
                        <span class="notification-time">3 days ago</span>
                    </div>
                </div>
            </div>
            <div class="notification-footer">
                <a href="#">View all notifications</a>
            </div>
        `;
        
        notificationBtn.appendChild(notificationDropdown);
        
        notificationBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            notificationDropdown.classList.toggle('active');
        });
        
        // Close dropdown when clicking elsewhere
        document.addEventListener('click', function() {
            notificationDropdown.classList.remove('active');
        });
        
        // Mark all as read
        const markAllReadBtn = notificationDropdown.querySelector('.mark-all-read');
        markAllReadBtn.addEventListener('click', function() {
            const unreadItems = notificationDropdown.querySelectorAll('.unread');
            unreadItems.forEach(item => {
                item.classList.remove('unread');
            });
            
            // Update badge
            const badge = notificationBtn.querySelector('.badge');
            if (badge) {
                badge.remove();
            }
        });
    }
    
    // User profile dropdown
    const userProfile = document.querySelector('.user-profile');
    if (userProfile) {
        const userDropdown = document.createElement('div');
        userDropdown.className = 'user-dropdown';
        userDropdown.innerHTML = `
            <div class="user-dropdown-header">
                <img src="../images/user3.jpg" alt="User">
                <div>
                    <h4>David K.</h4>
                    <p>Student</p>
                </div>
            </div>
            <div class="user-dropdown-links">
                <a href="#"><i class="fas fa-user"></i> My Profile</a>
                <a href="#"><i class="fas fa-cog"></i> Settings</a>
                <a href="#"><i class="fas fa-question-circle"></i> Help</a>
            </div>
            <div class="user-dropdown-footer">
                <a href="#" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        `;
        
        userProfile.appendChild(userDropdown);
        
        userProfile.addEventListener('click', function(e) {
            e.stopPropagation();
            userDropdown.classList.toggle('active');
        });
        
        // Close dropdown when clicking elsewhere
        document.addEventListener('click', function() {
            userDropdown.classList.remove('active');
        });
        
        // Logout button
        const logoutBtn = userDropdown.querySelector('.logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', function(e) {
                e.preventDefault();
                // In a real app, this would call your logout API
                alert('You have been logged out. Redirecting to home page...');
                // window.location.href = '../index.html';
            });
        }
    }
    
    // Session join button simulation
    const joinButtons = document.querySelectorAll('.session-actions .btn-primary');
    joinButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            // In a real app, this would launch the video session
            alert('Connecting to your tutoring session...');
        });
    });
});