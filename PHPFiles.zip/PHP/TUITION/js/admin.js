document.addEventListener('DOMContentLoaded', function() {
    // Initialize Platform Stats Chart
    const platformStatsChart = document.getElementById('platformStatsChart');
    
    if (platformStatsChart) {
        const ctx = platformStatsChart.getContext('2d');
        const chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
                datasets: [
                    {
                        label: 'New Students',
                        data: [120, 150, 180, 90, 130, 160, 200],
                        backgroundColor: 'rgba(74, 107, 255, 0.7)',
                        borderColor: 'rgba(74, 107, 255, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'New Tutors',
                        data: [25, 30, 22, 18, 28, 35, 40],
                        backgroundColor: 'rgba(40, 167, 69, 0.7)',
                        borderColor: 'rgba(40, 167, 69, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Sessions',
                        data: [450, 500, 600, 550, 700, 750, 800],
                        backgroundColor: 'rgba(255, 193, 7, 0.7)',
                        borderColor: 'rgba(255, 193, 7, 1)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return value;
                            }
                        }
                    }
                },
                interaction: {
                    mode: 'nearest',
                    axis: 'x',
                    intersect: false
                }
            }
        });
    }
    
    // Approval buttons functionality
    const approvalButtons = document.querySelectorAll('.approvals-table button');
    approvalButtons.forEach(button => {
        button.addEventListener('click', function() {
            const row = this.closest('tr');
            const userName = row.querySelector('.user-cell span').textContent;
            
            if (this.classList.contains('btn-success')) {
                // Approve action
                if (confirm(`Approve ${userName}'s application?`)) {
                    row.style.opacity = '0.5';
                    setTimeout(() => {
                        row.remove();
                        updatePendingCount();
                    }, 500);
                    
                    // Show approval message
                    showAdminAlert(`${userName} has been approved`, 'success');
                }
            } else if (this.classList.contains('btn-danger')) {
                // Reject action
                if (confirm(`Reject ${userName}'s application?`)) {
                    row.style.opacity = '0.5';
                    setTimeout(() => {
                        row.remove();
                        updatePendingCount();
                    }, 500);
                    
                    // Show rejection message
                    showAdminAlert(`${userName} has been rejected`, 'danger');
                }
            } else if (this.classList.contains('btn-outline')) {
                // View action
                alert(`Viewing details for ${userName}`);
            }
        });
    });
    
    function updatePendingCount() {
        const pendingRows = document.querySelectorAll('.approvals-table tbody tr');
        const pendingCount = pendingRows.length;
        
        // Update the "Pending Approvals" section header
        const sectionHeader = document.querySelector('.approvals-table').closest('.dashboard-section').querySelector('.section-header h3');
        sectionHeader.textContent = `Pending Approvals (${pendingCount})`;
    }
    
    function showAdminAlert(message, type) {
        const alertDiv = document.createElement('div');
        alertDiv.className = `admin-alert admin-alert-${type}`;
        alertDiv.innerHTML = `
            <p>${message}</p>
            <button class="close-alert">&times;</button>
        `;
        
        document.body.appendChild(alertDiv);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            alertDiv.classList.add('fade-out');
            setTimeout(() => {
                alertDiv.remove();
            }, 300);
        }, 5000);
        
        // Close button
        alertDiv.querySelector('.close-alert').addEventListener('click', function() {
            alertDiv.classList.add('fade-out');
            setTimeout(() => {
                alertDiv.remove();
            }, 300);
        });
    }
    
    // Initialize DataTable for tables (would require DataTables library in a real app)
    // $(document).ready(function() {
    //     $('.approvals-table table').DataTable();
    // });
    
    // Bulk actions
    const bulkActions = document.createElement('div');
    bulkActions.className = 'bulk-actions';
    bulkActions.innerHTML = `
        <select class="bulk-action-select">
            <option value="">Bulk Actions</option>
            <option value="approve">Approve Selected</option>
            <option value="reject">Reject Selected</option>
        </select>
        <button class="btn btn-primary btn-sm apply-bulk-action">Apply</button>
    `;
    
    const approvalsSection = document.querySelector('.approvals-table').closest('.dashboard-section');
    approvalsSection.querySelector('.section-header').appendChild(bulkActions);
    
    // Add checkboxes to each row
    const tableRows = document.querySelectorAll('.approvals-table tbody tr');
    tableRows.forEach(row => {
        const checkbox = document.createElement('td');
        checkbox.innerHTML = '<input type="checkbox" class="row-checkbox">';
        row.insertBefore(checkbox, row.firstChild);
    });
    
    // Add checkbox to header
    const tableHeader = document.querySelector('.approvals-table thead tr');
    const headerCheckbox = document.createElement('th');
    headerCheckbox.innerHTML = '<input type="checkbox" id="select-all">';
    tableHeader.insertBefore(headerCheckbox, tableHeader.firstChild);
    
    // Select all functionality
    document.getElementById('select-all').addEventListener('change', function() {
        const checkboxes = document.querySelectorAll('.row-checkbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = this.checked;
        });
    });
    
    // Apply bulk action
    document.querySelector('.apply-bulk-action').addEventListener('click', function() {
        const action = document.querySelector('.bulk-action-select').value;
        if (!action) {
            alert('Please select a bulk action');
            return;
        }
        
        const selectedRows = document.querySelectorAll('.row-checkbox:checked');
        if (selectedRows.length === 0) {
            alert('Please select at least one item');
            return;
        }
        
        if (confirm(`Are you sure you want to ${action} ${selectedRows.length} items?`)) {
            selectedRows.forEach(checkbox => {
                const row = checkbox.closest('tr');
                const userName = row.querySelector('.user-cell span').textContent;
                
                row.style.opacity = '0.5';
                setTimeout(() => {
                    row.remove();
                    updatePendingCount();
                }, 500);
                
                // In a real app, you would send an API request here
                console.log(`${action} application for ${userName}`);
            });
            
            showAdminAlert(`${selectedRows.length} items ${action}d`, 'success');
            document.getElementById('select-all').checked = false;
        }
    });
});