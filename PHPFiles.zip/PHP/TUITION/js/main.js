document.addEventListener('DOMContentLoaded', function() {
    // Mobile Menu Toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu');
    const navMenu = document.querySelector('nav ul');
    
    mobileMenuBtn.addEventListener('click', function() {
        navMenu.classList.toggle('active');
        mobileMenuBtn.innerHTML = navMenu.classList.contains('active') ? 
            '<i class="fas fa-times"></i>' : '<i class="fas fa-bars"></i>';
    });
    
    // Smooth Scrolling for Anchor Links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
                
                // Close mobile menu if open
                if (navMenu.classList.contains('active')) {
                    navMenu.classList.remove('active');
                    mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
                }
            }
        });
    });
    
    // Testimonial Slider
    const testimonials = document.querySelectorAll('.testimonial');
    const prevBtn = document.querySelector('.slider-prev');
    const nextBtn = document.querySelector('.slider-next');
    let currentTestimonial = 0;
    
    function showTestimonial(index) {
        testimonials.forEach(testimonial => {
            testimonial.classList.remove('active');
        });
        
        currentTestimonial = index;
        testimonials[currentTestimonial].classList.add('active');
    }
    
    prevBtn.addEventListener('click', function() {
        let newIndex = currentTestimonial - 1;
        if (newIndex < 0) newIndex = testimonials.length - 1;
        showTestimonial(newIndex);
    });
    
    nextBtn.addEventListener('click', function() {
        let newIndex = currentTestimonial + 1;
        if (newIndex >= testimonials.length) newIndex = 0;
        showTestimonial(newIndex);
    });
    
    // Auto-rotate testimonials
    let testimonialInterval = setInterval(() => {
        let newIndex = currentTestimonial + 1;
        if (newIndex >= testimonials.length) newIndex = 0;
        showTestimonial(newIndex);
    }, 5000);
    
    // Pause auto-rotation on hover
    const sliderContainer = document.querySelector('.testimonial-slider');
    sliderContainer.addEventListener('mouseenter', () => {
        clearInterval(testimonialInterval);
    });
    
    sliderContainer.addEventListener('mouseleave', () => {
        testimonialInterval = setInterval(() => {
            let newIndex = currentTestimonial + 1;
            if (newIndex >= testimonials.length) newIndex = 0;
            showTestimonial(newIndex);
        }, 5000);
    });
    
    // Load featured tutors (mock data)
    const tutorGrid = document.getElementById('tutor-grid');
    
    const tutors = [
        {
            name: "Dr. Sarah Johnson",
            subject: "Mathematics",
            rating: 4.9,
            reviews: 128,
            subjects: ["Algebra", "Calculus", "Geometry"],
            image: "images/tutor1.jpg"
        },
        {
            name: "Michael Chen",
            subject: "Computer Science",
            rating: 4.8,
            reviews: 95,
            subjects: ["Python", "JavaScript", "Web Development"],
            image: "images/tutor2.jpg"
        },
        {
            name: "Emily Rodriguez",
            subject: "Languages",
            rating: 4.7,
            reviews: 76,
            subjects: ["Spanish", "English", "French"],
            image: "images/tutor3.jpg"
        },
        {
            name: "David Kim",
            subject: "Science",
            rating: 4.9,
            reviews: 112,
            subjects: ["Chemistry", "Physics", "Biology"],
            image: "images/tutor4.jpg"
        }
    ];
    
    tutors.forEach(tutor => {
        const tutorCard = document.createElement('div');
        tutorCard.className = 'tutor-card';
        
        tutorCard.innerHTML = `
            <div class="tutor-img">
                <img src="${tutor.image}" alt="${tutor.name}">
            </div>
            <div class="tutor-info">
                <h3>${tutor.name}</h3>
                <p>${tutor.subject} Tutor</p>
                <div class="tutor-rating">
                    <div class="stars">
                        ${'<i class="fas fa-star"></i>'.repeat(Math.floor(tutor.rating))}
                        ${tutor.rating % 1 >= 0.5 ? '<i class="fas fa-star-half-alt"></i>' : ''}
                    </div>
                    <span class="reviews">(${tutor.reviews} reviews)</span>
                </div>
                <div class="tutor-subjects">
                    ${tutor.subjects.map(subject => `<span class="subject-tag">${subject}</span>`).join('')}
                </div>
                <a href="#" class="btn btn-primary">View Profile</a>
            </div>
        `;
        
        tutorGrid.appendChild(tutorCard);
    });
    
    // Scroll reveal animation
    const scrollReveal = ScrollReveal({
        origin: 'bottom',
        distance: '60px',
        duration: 1000,
        delay: 200,
        reset: true
    });
    
    scrollReveal.reveal('.hero-content, .hero-image', { delay: 300 });
    scrollReveal.reveal('.step', { interval: 200 });
    scrollReveal.reveal('.tutor-card, .course-card', { interval: 200 });
});