document.addEventListener('DOMContentLoaded', function() {
    // Payment modal
    const paymentModal = document.createElement('div');
    paymentModal.className = 'payment-modal';
    paymentModal.innerHTML = `
        <div class="payment-container">
            <button class="close-payment">&times;</button>
            <h2>Make a Payment</h2>
            
            <div class="payment-methods">
                <div class="payment-method active" data-method="card">
                    <i class="far fa-credit-card"></i>
                    <span>Credit/Debit Card</span>
                </div>
                <div class="payment-method" data-method="paypal">
                    <i class="fab fa-paypal"></i>
                    <span>PayPal</span>
                </div>
                <div class="payment-method" data-method="bank">
                    <i class="fas fa-university"></i>
                    <span>Bank Transfer</span>
                </div>
            </div>
            
            <div class="payment-content active" id="card-payment">
                <form id="card-form">
                    <div class="form-group">
                        <label for="card-number">Card Number</label>
                        <input type="text" id="card-number" placeholder="1234 5678 9012 3456">
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="card-expiry">Expiry Date</label>
                            <input type="text" id="card-expiry" placeholder="MM/YY">
                        </div>
                        <div class="form-group">
                            <label for="card-cvc">CVC</label>
                            <input type="text" id="card-cvc" placeholder="123">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="card-name">Name on Card</label>
                        <input type="text" id="card-name" placeholder="John Doe">
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Pay $45.00</button>
                </form>
            </div>
            
            <div class="payment-content" id="paypal-payment">
                <div class="paypal-info">
                    <p>You will be redirected to PayPal to complete your payment</p>
                    <button class="btn btn-paypal">
                        <i class="fab fa-paypal"></i> Pay with PayPal
                    </button>
                </div>
            </div>
            
            <div class="payment-content" id="bank-payment">
                <div class="bank-info">
                    <p>Please transfer the payment to the following bank account:</p>
                    <div class="bank-details">
                        <p><strong>Bank Name:</strong> EduConnect Bank</p>
                        <p><strong>Account Number:</strong> 1234567890</p>
                        <p><strong>Routing Number:</strong> 987654321</p>
                        <p><strong>Amount:</strong> $45.00</p>
                        <p><strong>Reference:</strong> EC-12345</p>
                    </div>
                    <button class="btn btn-primary">I've Made the Transfer</button>
                </div>
            </div>
            
            <div class="payment-security">
                <i class="fas fa-lock"></i>
                <span>Secure Payment</span>
            </div>
        </div>
    `;
    
    document.body.appendChild(paymentModal);
    
    // Payment method switching
    const paymentMethods = document.querySelectorAll('.payment-method');
    const paymentContents = document.querySelectorAll('.payment-content');
    
    paymentMethods.forEach(method => {
        method.addEventListener('click', function() {
            const methodId = this.dataset.method;
            
            paymentMethods.forEach(m => m.classList.remove('active'));
            paymentContents.forEach(c => c.classList.remove('active'));
            
            this.classList.add('active');
            document.getElementById(`${methodId}-payment`).classList.add('active');
        });
    });
    
    // Open payment modal
    const payButtons = document.querySelectorAll('.btn-outline.btn-sm');
    payButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (this.textContent.trim() === 'Pay Now') {
                e.preventDefault();
                paymentModal.classList.add('active');
                document.body.style.overflow = 'hidden';
            }
        });
    });
    
    // Close payment modal
    const closePayment = document.querySelector('.close-payment');
    closePayment.addEventListener('click', function() {
        paymentModal.classList.remove('active');
        document.body.style.overflow = '';
    });
    
    paymentModal.addEventListener('click', function(e) {
        if (e.target === paymentModal) {
            paymentModal.classList.remove('active');
            document.body.style.overflow = '';
        }
    });
    
    // Card form submission
    const cardForm = document.getElementById('card-form');
    if (cardForm) {
        cardForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Validate form
            const cardNumber = document.getElementById('card-number').value;
            const cardExpiry = document.getElementById('card-expiry').value;
            const cardCvc = document.getElementById('card-cvc').value;
            const cardName = document.getElementById('card-name').value;
            
            if (!cardNumber || !cardExpiry || !cardCvc || !cardName) {
                alert('Please fill in all card details');
                return;
            }
            
            // Simple validation for demo purposes
            if (!/^\d{16}$/.test(cardNumber.replace(/\s/g, ''))) {
                alert('Please enter a valid 16-digit card number');
                return;
            }
            
            if (!/^\d{2}\/\d{2}$/.test(cardExpiry)) {
                alert('Please enter expiry date in MM/YY format');
                return;
            }
            
            if (!/^\d{3,4}$/.test(cardCvc)) {
                alert('Please enter a valid CVC (3 or 4 digits)');
                return;
            }
            
            // Show processing state
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
            submitBtn.disabled = true;
            
            // Simulate payment processing
            setTimeout(() => {
                // Reset button
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
                
                // Close modal
                paymentModal.classList.remove('active');
                document.body.style.overflow = '';
                
                // Show success message
                alert('Payment successful! Thank you for your payment.');
                
                // In a real app, you would update the UI to reflect the paid status
                const pendingPayments = document.querySelectorAll('.status-badge.warning');
                if (pendingPayments.length > 0) {
                    pendingPayments[0].classList.remove('warning');
                    pendingPayments[0].classList.add('success');
                    pendingPayments[0].textContent = 'Completed';
                    
                    const payButton = pendingPayments[0].closest('tr').querySelector('.btn-outline');
                    payButton.textContent = 'Receipt';
                }
            }, 2000);
        });
    }
    
    // PayPal button
    const paypalButton = document.querySelector('.btn-paypal');
    if (paypalButton) {
        paypalButton.addEventListener('click', function() {
            // In a real app, this would redirect to PayPal
            alert('Redirecting to PayPal...');
        });
    }
    
    // Bank transfer confirmation
    const bankConfirmButton = document.querySelector('#bank-payment .btn-primary');
    if (bankConfirmButton) {
        bankConfirmButton.addEventListener('click', function() {
            if (confirm('Have you completed the bank transfer?')) {
                // Close modal
                paymentModal.classList.remove('active');
                document.body.style.overflow = '';
                
                // Show confirmation message
                alert('Thank you! Your payment will be processed once we receive the bank transfer.');
                
                // In a real app, you would update the UI
                const pendingPayments = document.querySelectorAll('.status-badge.warning');
                if (pendingPayments.length > 0) {
                    pendingPayments[0].classList.remove('warning');
                    pendingPayments[0].classList.add('info');
                    pendingPayments[0].textContent = 'Processing';
                    
                    const payButton = pendingPayments[0].closest('tr').querySelector('.btn-outline');
                    payButton.textContent = 'Details';
                }
            }
        });
    }
});