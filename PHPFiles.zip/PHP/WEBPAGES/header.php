<!DOCTYPE html>
<html lang="en">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <head><title>My site</title></head>

<body>
    <head><h1>Welcome to my site</h1></head>
</body>
</html>