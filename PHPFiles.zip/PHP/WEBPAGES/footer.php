<html>
<body>
<footer><p>&copy; 2025My Site</p></footer>
</body>
</html>