<?php
include ("header.php");
?>
<main>
<p>This is the homepage content</p>
</main>
<?php
include ("footer.php");
?>
